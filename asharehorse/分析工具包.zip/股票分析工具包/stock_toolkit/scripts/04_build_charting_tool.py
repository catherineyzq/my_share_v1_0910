#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
04_build_charting_tool.py —— 生成「可交互画线工具」单文件 HTML

用法:
    python3 04_build_charting_tool.py 000997_daily.csv 新大陆 000997
    python3 04_build_charting_tool.py 000997_daily.csv 新大陆 000997 --bars 60 --out tool.html

产出:
    一个自包含 HTML（Canvas + 原生 JS，无外部依赖，离线可用）
    功能: 趋势线 / 水平线 / 垂直线 / 矩形 / 三角形 / 斐波那契 / 文字标注
          选择移动、端点调整、撤销重做、磁吸、导出PNG、导入导出JSON
说明:
    图形逻辑在 JS 端；本脚本负责把 K 线数据注入模板。
    模板见同目录 charting_template.html（若不存在则用内置模板）。
"""
import sys, csv, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "charting_template.html")


def load_bars(path, bars_n):
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    for r in rows:
        for k in ("open", "close", "high", "low", "vol"):
            r[k] = float(r[k])
    seg = rows[-bars_n:]
    return [{"d": r["date"], "o": r["open"], "c": r["close"],
             "h": r["high"], "l": r["low"], "v": int(r["vol"])} for r in seg]


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)
    csv_path, name, code = sys.argv[1], sys.argv[2], sys.argv[3]
    bars_n = 60
    if "--bars" in sys.argv:
        bars_n = int(sys.argv[sys.argv.index("--bars") + 1])
    out = None
    if "--out" in sys.argv:
        out = sys.argv[sys.argv.index("--out") + 1]
    out = out or f"{code}_画线工具.html"

    bars = load_bars(csv_path, bars_n)
    if not os.path.exists(TEMPLATE):
        print(f"⚠ 找不到模板 {TEMPLATE}")
        print("  请把 charting_template.html 放在同目录，或从发行包中恢复。")
        sys.exit(2)

    html = open(TEMPLATE, encoding="utf-8").read()
    html = html.replace("__BARS__", json.dumps(bars, ensure_ascii=False))
    html = html.replace("__NAME__", name).replace("__CODE__", code)
    html = html.replace("__RANGE__", f"{bars[0]['d']} ~ {bars[-1]['d']}")

    open(out, "w", encoding="utf-8").write(html)
    print(f"已生成 -> {os.path.abspath(out)}")
    print(f"  {name} {code}  {len(bars)} 根  {bars[0]['d']} ~ {bars[-1]['d']}")
    print("  浏览器打开即可画线（离线可用）")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
7_run_daily.py — 投研图文工作台 · 每日全链驱动（总仓版 / 持续迭代）
================================================================================
用途：一条命令把“三池 md + 三池图文 html”跑完，输入基准日即可，无需逐条记命令。

原理（对应 0_README 之 7→9 依赖）：
  5_回马枪扫描器.py  YYYYMMDD <mode> tec   →  每日记录/YYYY-MM-DD/{候选池,变体池,反包池}_{日期}.md
  6_图文分析生成器.py YYYYMMDD --pool x    →  每日记录/YYYY-MM-DD/图文池_{候选池|变体池|反包池}_{日期}.html

用法示例：
  python3 7_run_daily.py 20260907            # 三池全跑 + 三份图文 html
  python3 7_run_daily.py 20260907 --md-only  # 只产三池 md，不跑图文
  python3 7_run_daily.py 20260907 fanbao     # 仅跑反包池全链（快速体检一池用）

约定：所有实体脚本与本文件同目录；运行需联网(东财涨停池+新浪K线+腾讯PE)。
================================================================================
"""
import argparse
import datetime as dt
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCAN = os.path.join(HERE, "5_回马枪扫描器.py")      # 池 md 源
GEN = os.path.join(HERE, "6_图文分析生成器.py")      # 池 md → 图文 html

# mode(cli) -> (池中文, 生成器 --pool)
POOLS = [
    ("main", "候选池", "main"),
    ("longshadow", "变体池", "longshadow"),
    ("fanbao", "反包池", "fanbao"),
]


def log(m):
    print(m, flush=True)


def run(cmd, tag):
    log(f"[run] {tag}: {' '.join(cmd)}")
    r = subprocess.run(cmd, cwd=HERE, capture_output=True, text=True, timeout=1500)
    # 打印子进程 stderr 里带 [i]/[w]/[✓] 的关键行，控制篇幅
    for line in (r.stdout + r.stderr).splitlines():
        if any(k in line for k in ("[✓]", "[i]", "[w]", "解析到", "已写出", "反包形态命中",
                                   "过滤后", "[1/", "[2/", "[3/", "[4/", "[5/")):
            log("   " + line.strip())
    if r.returncode != 0:
        log(f"[!] {tag} 失败(rc={r.returncode})，尾部输出：")
        tail = (r.stdout + r.stderr).strip().splitlines()[-8:]
        for line in tail:
            log("     " + line)
    return r.returncode


def md_dir(date_s):
    d = dt.datetime.strptime(date_s, "%Y%m%d").date()
    return os.path.join(HERE, "每日记录", d.strftime("%Y-%m-%d"))


def md_exists(date_s, cn):
    d = dt.datetime.strptime(date_s, "%Y%m%d").date()
    return os.path.exists(os.path.join(HERE, "每日记录", d.strftime("%Y-%m-%d"),
                                      f"{cn}_{date_s}.md"))


def main():
    ap = argparse.ArgumentParser(description="投研图文工作台 · 每日全链驱动")
    ap.add_argument("date", nargs="?", default=None)
    ap.add_argument("only_mode", nargs="?", default="all",
                    help="all|main|longshadow|fanbao")
    ap.add_argument("--md-only", action="store_true", help="只产 md，不出图文 html")
    args = ap.parse_args()

    date_s = args.date or dt.date.today().strftime("%Y%m%d")
    only = args.only_mode
    pools = [p for p in POOLS if only in ("all", p[0])]
    if not pools:
        log("[!] 未知模式，用 all|main|longshadow|fanbao")
        sys.exit(2)

    log(f"== 投研图文工作台 · 每日全链 | 日期 {date_s} | 池：{[p[1] for p in pools]} ==")

    ok_all = True
    # 阶段① 三池 md
    for mode, cn, gen_pool in pools:
        log(f"\n—— 阶段① {cn} md ——")
        rc = run([sys.executable, SCAN, date_s, mode, "tec"], cn + "-md")
        # fanbao 反包可能无符合票情况：md 仍生成即可继续，不硬判 rc<0 by returncode
        if rc != 0:
            log(f"[.] {cn} md 未正常返回，仍检查产物…")
        if not md_exists(date_s, cn):
            log(f"[!] {cn} 未产出 {cn}_{date_s}.md")
            ok_all = False
        else:
            log(f"[✓] {cn} md 就绪")

    # 阶段② 图文 html（每个池有自己的图文 html；候选池等有额外依赖拉现成）
    if not args.md_only:
        for mode, cn, gen_pool in pools:
            if not md_exists(date_s, cn):
                continue
            log(f"\n—— 阶段② {cn} 图文 html ——")
            rc = run([sys.executable, GEN, date_s, "--pool", gen_pool], cn + "-html")
            out = os.path.join(md_dir(date_s), f"图文池_{cn}_{date_s}.html")
            if rc == 0 and os.path.exists(out):
                log(f"[✓] {cn} 图文 html: {out}")
                ok_all = ok_all and True
            else:
                ok_all = False

    log("\n== 完成。整体状态：" + ("OK" if ok_all else "有池未产出，见上方 [!]") + " ==")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())

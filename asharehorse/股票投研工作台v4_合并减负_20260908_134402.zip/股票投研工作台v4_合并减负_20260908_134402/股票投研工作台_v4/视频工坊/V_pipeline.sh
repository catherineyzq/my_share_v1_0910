#!/usr/bin/env bash
# =========================================================
# 视频工坊 2/2 · V_pipeline.sh  （步骤1 抽帧/解析  + 步骤2 提音 + 步骤5 归档/zip/骨架）
# 用法: bash V_pipeline.sh <视频> <作者/出处> [fps，默认0.5]
# 在当前目录生成:  V_<主题>_<作者>_<YYYYMMDD>/  及同名 .zip
#   ├ README.md 、源视频拷贝、抽帧N张_frame/*.jpg、音轨16k/screen.wav
#   ├ OCR原文/scan_*.txt(粗扫) 、拆解与总结/（放置“待写主稿”骨架）
#   ✔ STEP3/STEP4(总结、找K线量价标的口径) 由作业：见生成的“拆解与总结/如何继续.md”
# =========================================================
set -uo pipefail
SRC="${1:?用法: bash V_pipeline.sh <视频路径> <作者> [fps]}"
AUTHOR="${2:-unknown}"
FPS="${3:-0.5}"

# 取干净主题短名
BASE="$(basename "$SRC")"; STEM="${BASE%.*}"
# 去掉常见抖音尾码 '-' 抖音_数字 / ' - 抖音'
THEME=$(printf '%s' "$STEM" | sed -E 's/[[:space:]]*[-_—]+(抖音)[[:space:]_]*[0-9A-Za-z_-]*$//I; s/[[:space:]]+/-/g')
THEME="${THEME:-video}"

for b in ffmpeg ffprobe tesseract zip; do command -v "$b" >/dev/null || { echo "缺 $b → 先 bash 视频工坊/V_env_setup.sh"; exit 1; }; done

DR=$(date +%Y%m%d)
DT=$(date +%Y%m%d_%H%M%S)
FOLDER="V_${THEME}_${AUTHOR}_${DT}"   # 命名含日期+时分秒，同日多次/多视频不覆盖
mkdir -p "$FOLDER/抽帧_tmp" "$FOLDER/音轨16k" "$FOLDER/OCR原文" "$FOLDER/拆解与总结"
echo "════ 视频工坊 · 当前目录建独立夹 $FOLDER ════"

DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$SRC" | head -1)
echo "[1/4] 源时长≈${DUR}s → 拷贝源视频+covers"
# 源视频（压不压？为保原样，直接保留原文件引用于独立夹，若同盘则 mv 更省；这里做拷贝便于目录自含）
cp "$SRC" "$FOLDER/$(basename "$SRC")" 2>/dev/null || { cp "$SRC" "$FOLDER/source.mp4"; }
W=$(ffprobe -v error -select_streams v -show_entries stream=width -of csv=p=0 "$SRC"|head -1)
H=$(ffprobe -v error -select_streams v -show_entries stream=height -of csv=p=0 "$SRC"|head -1)
echo "   分辨率 ${W}x${H}"

echo "[2/4] 抽帧 fps=$FPS → 抽帧_tmp/frame_%03d.jpg"
ffmpeg -y -loglevel error -i "$SRC" -vf "fps=$FPS" -q:v 3 "$FOLDER/抽帧_tmp/frame_%03d.jpg" >/dev/null 2>&1
NFRM=$(ls "$FOLDER/抽帧_tmp/"*.jpg 2>/dev/null | wc -l)
echo "   共 $NFRM 帧"

echo "[3/4] OCR 粗扫(chi_sim) → OCR原文/"
if [ "$NFRM" -gt 0 ]; then
  i=0
  for f in "$FOLDER/抽帧_tmp/"*.jpg; do
    i=$((i+1)); n=$(printf '%03d' "$i")
    OUT="$FOLDER/OCR原文/scan_${n}.txt"
    tesseract "$f" "$FOLDER/OCR原文/_tmp_${n}" -l chi_sim+eng --psm 6 >/dev/null 2>&1 || tesseract "$f" "$FOLDER/OCR原文/_tmp_${n}" -l chi_sim+eng --psm 11 >/dev/null 2>&1
    [ -f "$FOLDER/OCR原文/_tmp_${n}.txt" ] && { awk 'NF' "$FOLDER/OCR原文/_tmp_${n}.txt" > "$OUT"; rm -f "$FOLDER/OCR原文/_tmp_${n}.txt"; } || echo "(该帧无文字)" > "$OUT"
  done
  # 目录名整理：重命名帧夹 → 抽帧N张_frame
  mv "$FOLDER/抽帧_tmp" "$FOLDER/抽帧${NFRM}张_frame"
else
  rm -rf "$FOLDER/抽帧_tmp"
fi

# —— OCR 采集完，自动清洗成“可读文字稿”（生 raw 保留在 OCR原文/ 作溯源）
SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -d "$FOLDER/OCR原文" ] && ls "$FOLDER/OCR原文/"scan_*.txt >/dev/null 2>&1; then
  bash "$SELF/V_clean_ocr.sh" "$FOLDER/OCR原文"
fi

echo "[4/4] 提音(16k/mono) → 音轨16k/screen.wav"
ffmpeg -y -loglevel error -i "$SRC" -vn -acodec pcm_s16le -ar 16000 -ac 1 "$FOLDER/音轨16k/screen.wav" >/dev/null 2>&1
ls -la "$FOLDER/音轨16k/screen.wav" >/dev/null 2>&1 && echo "   音轨OK" || echo "   (音轨无？可能纯视频) "

# —— README 占位（动态写入）
cat > "$FOLDER/README.md" <<EOF
# $(basename "$FOLDER")
> 视频工坊自动建档 · ${DT} · 作者：$AUTHOR
> 源：$SRC

## 五步进度
- [x] STEP1 解析(抽帧$([ "$NFRM" -gt 0 ] && echo "${NFRM}张" || echo 0张)+OCR粗扫)
- [x] STEP2 提取音轨(16k/mono)
- [ ] STEP3 总结稿(待写到 拆解与总结/)
- [ ] STEP4 找“对应K线量价”判定清单/条件雏形
- [x] 归档(独立夹+zip)

## 夹内
- 源视频.mp4 / 抽帧${NFRM}张_frame/(帧号≈×2s) / 音轨16k/screen.wav
- OCR原文/scan_*.txt（粗扫，含错字，为口径溯源）
- 拆解与总结/（主稿+“如何继续”置于该夹）

> 非静态看片建议配 8_视频讲解作业手册.md 走完整五步。
EOF

cat > "$FOLDER/拆解与总结/如何继续.md" <<'EOF'
# 待作业（STEP3→4）说明
1) 用 `OCR原文/*.txt` + 关键帧画面回看，重建“该秒在讲什么 ↔ 它在判断K线/量价”。
2) 对内容切换段代表帧做“裁字幕带OCR精修”，把确证句从〔语意〕提为可引用。
3) 产出一篇独立稿，固定骨架见 8_视频讲解作业手册 §四(A~F)。
4) 产出“字段化判定清单”（§五），供后续接 5_回马枪 字段 / 选标的输入。
5) 完成即在 README 勾 STEP3/STEP4。
EOF

# —— zip 独立包（在上一层）
cd "$FOLDER" && cd - >/dev/null
zip -r -q "${FOLDER}.zip" "$FOLDER" >/dev/null 2>&1
echo "════ 完成："
echo "  📁 $FOLDER/"
echo "  📦 $(basename "${FOLDER}.zip")  (同夹已打)"
echo "  下一步: 见 $FOLDER/拆解与总结/如何继续.md（STEP3/4 由作业产出主稿）"
echo "  （文件大小: $(du -h "${FOLDER}.zip" | cut -f1)）"

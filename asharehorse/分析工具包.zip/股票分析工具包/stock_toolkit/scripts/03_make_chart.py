#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
03_make_chart.py —— 生成 K 线引线图（PNG，白底，带均线与关键位）

用法:
    python3 03_make_chart.py 000997_daily.csv 新大陆 000997
    python3 03_make_chart.py 000997_daily.csv 新大陆 000997 --bars 45 --font /path/cjk.otf

依赖: Pillow (pip install Pillow)
字体: 需要中文字体。若未指定 --font，会依次尝试常见路径。
      没有中文字体时，可先下载：
      https://mirrors.tuna.tsinghua.edu.cn/adobe-fonts/source-han-sans/SubsetOTF/CN/SourceHanSansCN-Regular.otf
"""
import sys, csv, os, statistics
from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    "/workspace/cjk.otf",
    "/usr/share/fonts/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "C:/Windows/Fonts/msyh.ttc",
]


def pick_font(custom=None):
    for p in ([custom] if custom else []) + FONT_CANDIDATES:
        if p and os.path.exists(p):
            return p
    return None


def load(path):
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    for r in rows:
        for k in ("open", "close", "high", "low", "vol"):
            r[k] = float(r[k])
    return rows


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)
    csv_path, name, code = sys.argv[1], sys.argv[2], sys.argv[3]
    bars_n = 45
    if "--bars" in sys.argv:
        bars_n = int(sys.argv[sys.argv.index("--bars") + 1])
    font_path = None
    if "--font" in sys.argv:
        font_path = sys.argv[sys.argv.index("--font") + 1]
    font_path = pick_font(font_path)
    if not font_path:
        print("⚠ 未找到中文字体，中文会显示为方块。请用 --font 指定字体路径。")

    rows = load(csv_path)
    seg = rows[-bars_n:]
    W, H = 1400, 760
    im = Image.new("RGB", (W, H), (255, 255, 255))
    d = ImageDraw.Draw(im)

    def F(sz):
        return ImageFont.truetype(font_path, sz) if font_path else ImageFont.load_default()

    f20, f13, f12 = F(21), F(14), F(13)
    pl, pr, pt, pb = 80, 240, 60, 110
    cw, ch = W - pl - pr, H - pt - pb
    hi = max(r["high"] for r in seg)
    lo = min(r["low"] for r in seg)
    rng = hi - lo or 1

    def X(i): return pl + (i + 0.5) * cw / len(seg)
    def Y(p): return pt + (hi - p) * ch / rng

    vols = [r["vol"] for r in seg]
    mv = max(vols)
    def VY(v): return H - pb - (v / mv) * 95

    closes = [r["close"] for r in rows]
    def ma(idx, p):
        return None if idx + 1 < p else sum(closes[idx + 1 - p:idx + 1]) / p

    d.text((pl, 20), f"{name} {code} · 近{bars_n}个交易日引线（前复权）", font=f20, fill=(20, 20, 20))

    # 网格
    for g in range(5):
        p = lo + rng * g / 4
        y = Y(p)
        d.line([(pl, y), (W - pr, y)], fill=(225, 225, 228))
        d.text((pl - 12, y), f"{p:.2f}", font=f12, fill=(90, 90, 95), anchor="rm")

    # 均线
    for p, col in ((5, (230, 170, 0)), (20, (30, 110, 220)), (60, (210, 40, 110))):
        pts = []
        for i in range(len(seg)):
            m = ma(len(rows) - len(seg) + i, p)
            if m:
                pts.append((X(i), Y(m)))
        if len(pts) > 1:
            d.line(pts, fill=col, width=3)

    # K 线 + 量
    UP, DN = (210, 30, 35), (20, 140, 80)
    for i, r in enumerate(seg):
        x = X(i)
        c = UP if r["close"] >= r["open"] else DN
        d.line([(x, Y(r["high"])), (x, Y(r["low"]))], fill=c, width=2)
        y1, y2 = Y(max(r["open"], r["close"])), Y(min(r["open"], r["close"]))
        d.rectangle([x - 5, y1, x + 5, max(y2, y1 + 2)], fill=c)
        d.rectangle([x - 5, VY(r["vol"]), x + 5, H - pb],
                    fill=tuple(min(255, int(v * 0.55) + 100) for v in c))

    # 关键位：区间高/低 + 均线
    keys = [
        (max(r["high"] for r in seg), f"区间高 {max(r['high'] for r in seg):.2f}", (190, 120, 0)),
        (min(r["low"] for r in seg), f"区间低 {min(r['low'] for r in seg):.2f}", (20, 140, 80)),
        (ma(len(rows) - 1, 20), f"MA20 {ma(len(rows)-1,20):.2f}", (30, 110, 220)),
        (ma(len(rows) - 1, 60), f"MA60 {ma(len(rows)-1,60):.2f}", (210, 40, 110)),
    ]
    for p, lab, col in keys:
        if p is None:
            continue
        y = Y(p)
        for xx in range(pl, W - pr, 12):
            d.line([(xx, y), (xx + 7, y)], fill=col)
        d.text((W - pr + 10, y), lab, font=f13, fill=col, anchor="lm")

    # 日期
    for i in range(0, len(seg), max(1, len(seg) // 7)):
        d.text((X(i), H - pb + 22), seg[i]["date"][5:], font=f12, fill=(90, 90, 95), anchor="mm")

    d.text((pl, H - 22), "黄=MA5  蓝=MA20  粉=MA60 ｜ 下方柱=成交量 ｜ 数据截至 " + rows[-1]["date"],
           font=f13, fill=(90, 90, 95))

    out = f"{code}_引线图.png"
    im.save(out)
    print(f"已保存 -> {os.path.abspath(out)}  ({W}x{H})")


if __name__ == "__main__":
    main()

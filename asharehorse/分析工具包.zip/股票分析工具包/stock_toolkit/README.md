# A股日线量价分析工具包

一套纯 Python + 原生 JS 的离线工具，用于 A 股日线数据的抓取、量价结构分析和 K 线图生成。
**无第三方依赖（除 Pillow），单文件脚本，可直接交给 AI 助手（如豆包）执行或参考。**

---

## 目录结构

```
stock_toolkit/
├── README.md                  ← 本文件
├── scripts/
│   ├── 01_fetch_kline.py      ← 抓取日线数据（东方财富公开接口）
│   ├── 02_analyze.py          ← 量价结构分析（均线/关键位/量能）
│   ├── 03_make_chart.py       ← 生成 K 线引线图 PNG
│   ├── 04_build_charting_tool.py  ← 生成可交互画线工具 HTML
│   └── charting_template.html ← 画线工具模板（供 04 调用）
└── data/
    └── 000997_daily.csv       ← 示例数据（新大陆，200 根日线）
```

---

## 快速开始

### 1. 抓数据

```bash
python3 scripts/01_fetch_kline.py 000997          # 新大陆，默认 200 根
python3 scripts/01_fetch_kline.py 600845 300      # 宝信软件，300 根
python3 scripts/01_fetch_kline.py 002487 200 dajin.csv   # 指定输出名
```

输出 CSV，表头：
`date,open,close,high,low,vol,amount,amp,pct,chg,turnover`

- `vol` 单位 = 手
- `amount` 单位 = 元
- `pct` 单位 = %
- 前复权（`fqt=1`）

### 2. 分析

```bash
python3 scripts/02_analyze.py 000997_daily.csv --recent 50
```

输出纯文本报告（可直接贴给 AI）：
- 最新价 / 涨跌幅 / 换手
- MA5/10/20/30/60 及偏离度
- 区间最高/最低
- 量能 TOP10（天量日）
- 各周期均量对比
- 最近 N 根 K 线明细

### 3. 出图

```bash
# 需要 Pillow: pip install Pillow
python3 scripts/03_make_chart.py 000997_daily.csv 新大陆 000997
python3 scripts/03_make_chart.py 000997_daily.csv 新大陆 000997 --bars 45
```

生成白底 PNG，含 K 线、MA5/20/60、区间高低关键位、成交量。

**中文字体**：脚本会自动尝试常见路径。若都没有，先下载：

```bash
curl -o cjk.otf https://mirrors.tuna.tsinghua.edu.cn/adobe-fonts/source-han-sans/SubsetOTF/CN/SourceHanSansCN-Regular.otf
python3 scripts/03_make_chart.py 000997_daily.csv 新大陆 000997 --font cjk.otf
```

### 4. 生成画线工具

```bash
python3 scripts/04_build_charting_tool.py 000997_daily.csv 新大陆 000997
```

生成一个自包含 HTML，浏览器打开即可用。

---

## 画线工具功能

| 工具 | 说明 |
|---|---|
| 趋势线 | 两点连线，向两端自动延长 |
| 水平线 | 单击即画，右侧自动标价格 |
| 垂直线 | 标时间节点 |
| 矩形 | 框箱体 / 套牢区 |
| 三角形 | 拖出三角形，画三角收敛 |
| 斐波那契 | 两点定回撤，自动算 7 档价位 |
| 文字 | 单击加标注 |

操作：
- 画：选工具 → 按住拖动（水平线/垂直线/文字单击）
- 改：切「选择」→ 拖动图形整体 / 拖端点微调
- 删：选中按 `Delete`
- 撤销 `Ctrl+Z` / 重做 `Ctrl+Y` / 取消 `Esc`
- 磁吸：自动吸到最近的最高/最低/收盘价
- 缩放：鼠标滚轮
- 导出：PNG 图片 / JSON 数据（可再导入）

---

## 关键技术说明

### 东财接口

```
https://push2his.eastmoney.com/api/qt/stock/kline/get
  ?secid=0.000997          # 深市 0. / 沪市 1.
  &fields1=f1,f2,f3,f4,f5,f6
  &fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61
  &klt=101                 # 101=日线
  &fqt=1                   # 1=前复权
  &end=20500101
  &lmt=200                 # 返回根数
```

**必须带请求头**，否则可能被拒：
```
Referer: https://quote.eastmoney.com/
User-Agent: Mozilla/5.0 ...
```

返回 `data.klines` 为字符串数组，每行按 `fields2` 顺序逗号分隔。

### secid 前缀规则

| 市场 | 前缀 | 示例 |
|---|---|---|
| 深市（0 开头） | `0.` | 000997 → `0.000997` |
| 沪市（6 开头） | `1.` | 600845 → `1.600845` |
| 北交所（4/8 开头） | 需自行确认 | — |

前缀写错会取到错误标的。

---

## 分析口径（重要）

本工具包遵循以下分析原则，供 AI 参考：

1. **去标签化**：不给个股贴永久标签（如"出货票""妖股"），一律用"当前阶段的量价结构"动态描述。
2. **单根不硬断**：放量/冲高回落/炸板只记为"量出现了"，不咬定"主力出货/扫货"——单根 K 线看不出方向。
3. **方向交给后续 2-3 根**：
   - 大量后缩量回踩守稳 → 再放量收复天量高点 = 更像多方买走
   - 大量后阴跌、反抽缩量上不去、再放量下台阶 = 更像抛压持续
4. **分支尺**：给"到什么价 + 放什么量 = 翻成哪种结构"的分支判断，不定性一锤定音。

---

## 依赖

- Python 3.7+
- Pillow（仅 `03_make_chart.py` 需要）：`pip install Pillow`
- 中文字体（仅出图需要）

`01` / `02` / `04` 仅用标准库。

---

## 免责声明

本工具仅用于技术分析学习与复盘，所有数据来自公开接口，**不构成任何投资建议**。

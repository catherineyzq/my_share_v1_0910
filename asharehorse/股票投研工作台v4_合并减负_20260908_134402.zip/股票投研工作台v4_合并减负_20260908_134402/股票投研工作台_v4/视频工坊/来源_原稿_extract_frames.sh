#!/bin/bash
# ============================================================
# 视频抽帧 + 提取音轨 通用脚本（可在手机 nekobot 沙箱 / Termux 运行）
# 用法:
#   1) 先装 ffmpeg（Debian/Ubuntu 沙箱）:
#        apt-get update && apt-get install -y ffmpeg
#      Termux:
#        pkg install ffmpeg
#   2) 运行:
#        bash extract_frames.sh 视频.mp4 [每秒帧数, 默认1]
# 产物: frames_<视频名>/frame_001.jpg ... ; audio_<视频名>/screen.wav
# ============================================================
set -e
VIDEO="${1:?用法: bash extract_frames.sh <video.mp4> [fps]}"
FPS="${2:-1}"
NAME="$(basename "${VIDEO%.*}")"

OUT="frames_${NAME}"
AUD="audio_${NAME}"
mkdir -p "$OUT" "$AUD"

echo "[1/2] 抽帧 fps=$FPS -> $OUT/"
ffmpeg -y -i "$VIDEO" -vf "fps=$FPS" -q:v 3 "$OUT/frame_%03d.jpg"

echo "[2/2] 提取音轨(16k/mono) -> $AUD/screen.wav"
ffmpeg -y -i "$VIDEO" -vn -acodec pcm_s16le -ar 16000 -ac 1 "$AUD/screen.wav"

echo "完成: 帧数=$(ls "$OUT"/*.jpg 2>/dev/null | wc -l), 音频=$AUD/screen.wav"
echo "总览拼图(可选):"
echo "  ffmpeg -y -i \"$VIDEO\" -vf \"fps=$FPS,scale=320:180,tile=11x8\" -frames:v 1 $OUT/overview.jpg"

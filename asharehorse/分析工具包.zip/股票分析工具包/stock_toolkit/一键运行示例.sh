#!/bin/sh
# 一键跑通全流程：抓数据 -> 分析 -> 出图 -> 生成画线工具
# 用法: sh 一键运行示例.sh 000997 新大陆

CODE=${1:-000997}
NAME=${2:-新大陆}
DIR=$(dirname "$0")

echo "===== 1/4 抓取 $NAME $CODE 日线 ====="
python3 "$DIR/scripts/01_fetch_kline.py" "$CODE" 200 "$DIR/data/${CODE}_daily.csv"

echo ""
echo "===== 2/4 量价结构分析 ====="
python3 "$DIR/scripts/02_analyze.py" "$DIR/data/${CODE}_daily.csv" --recent 30

echo ""
echo "===== 3/4 生成引线图 ====="
python3 "$DIR/scripts/03_make_chart.py" "$DIR/data/${CODE}_daily.csv" "$NAME" "$CODE" --out "$DIR/${CODE}_引线图.png"

echo ""
echo "===== 4/4 生成画线工具 ====="
python3 "$DIR/scripts/04_build_charting_tool.py" "$DIR/data/${CODE}_daily.csv" "$NAME" "$CODE" --out "$DIR/${CODE}_画线工具.html"

echo ""
echo "===== 完成 ====="
echo "产物:"
echo "  $DIR/data/${CODE}_daily.csv"
echo "  $DIR/${CODE}_引线图.png"
echo "  $DIR/${CODE}_画线工具.html"

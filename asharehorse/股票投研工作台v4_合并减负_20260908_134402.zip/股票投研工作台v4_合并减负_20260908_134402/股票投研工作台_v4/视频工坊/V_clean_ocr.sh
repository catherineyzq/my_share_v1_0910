#!/usr/bin/env bash
# =========================================================
# 视频工坊 · V_clean_ocr.sh —— 把“逐帧 OCR 生 raw”清洗成“可读文字稿”
#   生 raw 特点：整帧常含竖排杂字/水印噪声/逐字空格 → 观感像乱码。
#   清洗：仅保留含中文的正文段，剔除装饰行/符号并把被拆散的字紧凑归并，
#   按帧号顺序拼成逐段可读稿。生 raw 本身保留（不改动 OCR原文/*.txt）。
# 用法:
#   bash V_clean_ocr.sh <OCR原文目录（或任一视频夹）> [输出文件路径，可省]
#   默认输出到 <OCR原文>/../拆解与总结/OCR文字草稿_清洗可读.txt
# =========================================================
set -uo pipefail
IN="${1:?用法: bash V_clean_ocr.sh <OCR原文目录> [输出]  }"
[ -d "$IN" ] || IN="$IN/OCR原文"
[ -d "$IN" ] || { echo "找不到 OCR原文目录: $IN"; exit 1; }
if [ $# -ge 2 ]; then OUT="$2"; else OUT="$(dirname "$IN")/拆解与总结/OCR文字草稿_清洗可读.txt"; fi
mkdir -p "$(dirname "$OUT")"

clean_frame(){  # $1=某帧txt -> 输出紧凑可读串（仅中文正文，过滤水印噪声残行）
  python3 - "$1" <<'PY'
import re, sys
p = sys.argv[1]
try:
    raw = open(p, encoding='utf-8', errors='ignore').read()
except Exception:
    sys.exit(0)
cjk = re.compile(r'[\u4e00-\u9fff]')
# 允许保留：汉字/数字/字母/中文常见标点/%（其余装饰符全丢弃）
allow = re.compile(r'[\u4e00-\u9fff0-9A-Za-z。，、；——“”？（）%\-—…]+')
buf = []
for ln in raw.splitlines():
    ln = ln.strip()
    if not cjk.search(ln):
        continue                       # 纯符号/水印/页码无中文 → 丢
    parts = allow.findall(ln)          # 只取合法字符碎片并自动去掉空格等
    joined = ''.join(parts)
    # 剔除整体仍是纯装饰（杠/井堆积出的 “-----” 之类）
    body = re.sub(r'[^一-龥0-9A-Za-z（）]', '', joined)
    if not body.strip():
        continue
    buf.append(joined)
out = ''.join(buf)
han = len(re.findall(r'[一-龥]', out))
if han >= 4:
    print(out)
sys.exit(0)
PY
}

: > "$OUT"
i=0
for f in "$IN"/scan_*.txt; do
  [ -e "$f" ] || continue
  i=$((i+1))
  seg=$(clean_frame "$f")
  if [ -n "$seg" ]; then
    printf '%s\n' "[第${i}段 $(basename "$f" .txt)] $seg" >> "$OUT"
  fi
done

if [ ! -s "$OUT" ]; then printf '（该片 OCR 几乎无可重建中文段，未生成有效文字稿）\n' > "$OUT"; fi
echo "已生成: $OUT  （共 $(wc -l < "$OUT") 段可读文本；逐帧生序 raw 保留于 OCR原文/）"
grep -v '^\[' "$OUT" >/dev/null 2>&1 || true

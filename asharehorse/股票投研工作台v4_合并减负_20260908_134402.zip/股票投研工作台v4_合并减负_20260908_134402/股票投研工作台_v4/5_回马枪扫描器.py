#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回马枪扫描器 v1.0 ｜ 股票投研档案 · WorkBuddy 为bob重写
============================================================
用法：
  python3 回马枪扫描器.py [YYYYMMDD] [longshadow] [def|tec]

  YYYYMMDD    选股基准日（交易日）。缺省自动回退到最近交易日。
  longshadow  加此参数 → 扫描"长上影洗盘"变体池（输出 变体池_*.md）
  def|tec     PE 财务档：def=价值档(10~60) / tec=科技档(<=120)，默认 tec

主池逻辑（README v3.3 / 回马枪战法手册 机器部分）：
  五关①涨停基因：近25个交易日有放量实体涨停（板块自适应：10/20/30cm），1-3次
  五关②相对低位：距250日高点回撤>=12%；启动约束 现价<=首板前低点x1.5
  五关③回马枪形态：现价>=首板最低价；涨停后高点回撤 2~18%（最佳2-8%）；回踩缩量
  防雷(自动段)：ST剔除；PE 亏损/超档剔除（人工终审五关④仍须人工过）
  大级别避雷：330日视角，✗年线下+未站60日线 → 自动剔除；✓年线上 / △分水岭下
  机器三维评分(位置/回踩/量能 0-6) → A(6)/B(5)/C(4)/D(<=3)
  输出：每日记录/YYYY-MM-DD/候选池_YYYYMMDD.md

变体池 longshadow（v2.9 规格）：
  候选 = 全市场涨幅榜(>=2%) + 量比榜top300 + 近5日涨停/炸板池
  判"倍量长上影试盘"(量>=前5均1.5倍 & 长上影带攻击) →
    ①今日新试盘(跟踪,分强/普)  ②洗盘完成(缩量<=0.7 且 企稳，前面<=5日内有试盘)
  输出：每日记录/YYYY-MM-DD/变体池_YYYYMMDD.md

数据源：东财涨停池(push2ex) + 新浪日K/榜单 + 腾讯实时(PE)
注：新浪K线为未复权数据，除权日附近涨停判定可能失真。
仅供研究参考，不构成投资建议。
"""

import argparse
import datetime as dt
import json
import os
import re
import sys
import time

import requests

# ---------------------------------------------------------------- 基础配置
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
HDR_SINA = {"User-Agent": UA, "Referer": "https://finance.sina.com.cn"}
HDR_EM = {"User-Agent": UA}

S = requests.Session()
S.headers.update({"User-Agent": UA})

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ARCHIVE_ROOT = os.path.join(SCRIPT_DIR, "每日记录")

EM_UT = "7eea3edcaed734bea9cbfc24409ed989"
EM_ZT_URL = "https://push2ex.eastmoney.com/getTopicZTPool"
EM_ZB_URL = "https://push2ex.eastmoney.com/getTopicZBPool"
SINA_KLINE = "https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData"
SINA_RANK = ("https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/"
             "Market_Center.getHQNodeData")
QT_URL = "https://qt.gtimg.cn/q="


def log(msg):
    print(msg, flush=True)


def get_json(url, params=None, headers=None, retry=2):
    for i in range(retry + 1):
        try:
            r = S.get(url, params=params, headers=headers, timeout=12)
            r.raise_for_status()
            txt = r.text.strip()
            if not txt or txt in ("null", "[]"):
                return None
            return json.loads(txt)
        except Exception as e:
            if i == retry:
                raise
            time.sleep(0.6 * (i + 1))
    return None


# ---------------------------------------------------------------- 代码/板块工具
def sina_symbol(code):
    """6->sh, 0/3->sz, 其余(4/8/9北交)->bj"""
    if code.startswith(("60", "68", "9")):
        return "sh" + code
    if code.startswith(("00", "30", "20")):
        return "sz" + code
    return "bj" + code


def limit_pct(code):
    if code.startswith(("30", "68")):
        return 20.0
    if code.startswith(("4", "8", "92")):
        return 30.0
    return 10.0


def is_st(name):
    return "ST" in (name or "").upper()


# ---------------------------------------------------------------- 东财涨停池/炸板池
def fetch_zt_pool(date_str, pool_type="zt"):
    """date_str=YYYYMMDD；返回 list[dict(code,name,m,lbc,hybk,zdp,...)] 或 []"""
    url = EM_ZT_URL if pool_type == "zt" else EM_ZB_URL
    out = []
    for page in range(0, 3):
        params = {
            "ut": EM_UT, "dpt": "wz.ztzt", "Pageindex": page,
            "pagesize": 200, "sort": "fbt:asc", "date": date_str,
        }
        try:
            data = get_json(url, params=params, headers=HDR_EM)
        except Exception:
            break
        if not data or not data.get("data") or not data["data"].get("pool"):
            break
        out.extend(data["data"]["pool"])
        if len(out) >= data["data"].get("tc", 0):
            break
        time.sleep(0.1)
    return out


# ---------------------------------------------------------------- 新浪K线
def fetch_kline(code, n=520):
    """返回升序 bars:[{day,open,high,low,close,volume}] 未复权；失败返回 []"""
    try:
        data = get_json(SINA_KLINE, params={
            "symbol": sina_symbol(code), "scale": 240, "ma": "no", "datalen": n,
        }, headers=HDR_SINA)
    except Exception:
        return []
    if not data:
        return []
    out = []
    for b in data:
        try:
            out.append({
                "day": str(b["day"]),
                "open": float(b["open"]),
                "high": float(b["high"]),
                "low": float(b["low"]),
                "close": float(b["close"]),
                "volume": float(b["volume"]),
            })
        except (KeyError, TypeError, ValueError):
            continue
    return out


# ---------------------------------------------------------------- 腾讯快照(PE)
def fetch_qt_snaps(codes):
    """codes list -> {code: dict(name,price,pe)}；一次最多60只，自动分块。
    长跑进程高并发拉K线后，腾讯经透明代理偶发返回 200+21字节空响应：
    ①独立短生命周期会话 ②随机参数防缓存 ③空响应指数退避重试(2/4/6/8s)。"""
    codes = [c for c in codes if c]
    if not codes:
        return {}
    last_code, last_len, last_err = None, 0, ""
    for attempt in range(6):
        out = {}
        sess = requests.Session()
        sess.headers.update({"User-Agent": UA, "Referer": "https://gu.qq.com/"})
        ok_chunks = 0
        for i in range(0, len(codes), 55):
            chunk = codes[i:i + 55]
            syms = ",".join(sina_symbol(c) for c in chunk)
            try:
                r = sess.get(QT_URL + syms + f"&_r={int(time.time() * 1000) + i}",
                             timeout=12)
                r.raise_for_status()
                last_code, last_len = r.status_code, len(r.content)
                text = r.content.decode("gbk", errors="ignore")
                if len(text) < 50:          # 空/占位响应(如21B)视为失败块
                    continue
                got = 0
                for ln in text.split(";"):
                    if "=" not in ln or '="' not in ln:
                        continue
                    body = ln.split('="', 1)[1].rstrip('"')
                    f = body.split("~")
                    if len(f) < 40:
                        continue
                    code = f[2].strip()
                    def _num(x):
                        try:
                            return float(x)
                        except (TypeError, ValueError):
                            return None
                    out[code] = {
                        "name": f[1].strip(),
                        "price": _num(f[3]),
                        "pe": _num(f[39]),          # PE-TTM
                    }
                    got += 1
                if got:
                    ok_chunks += 1
            except Exception as e:
                last_err = f"{type(e).__name__}: {e}"
                continue
            time.sleep(0.1)
        if out:
            return out
        # 整批空/失败 → 退避重试
        wait = 2 * (attempt + 1)
        log(f"[w] qt 快照空/失败(HTTP {last_code} len={last_len} {last_err})，{wait}s后重试 "
            f"({attempt + 1}/6)")
        time.sleep(wait)
    return {}


def _em_market_of(code):
    """东财 secid 市场前缀：6/9→1(沪/B股/N)，0/3(深)→0，其余→0；按沪深实际。"""
    if code.startswith(("6", "9")) or code.startswith("5"):
        return "1"
    return "0"


def fetch_em_snaps(codes):
    """东财 push2 ulist.np 批量快照(名称/现价/PE-TTM)。腾讯被限流时的兜底源。
    与东财涨停池同域(push2)，长期稳定不被限流。
    f2=现价 f9=PE-TTM(亏损为负/空) f12=代码 f14=名称。返回 {code:{name,price,pe}}。
    注意：push2 首条新连接偶发被远端掐断(RemoteDisconnected) → 自建会话+重连重试。"""
    codes = [c for c in codes if c]
    if not codes:
        return {}
    sess = requests.Session()
    sess.headers.update({
        "User-Agent": UA,
        "Referer": "https://quote.eastmoney.com/",
    })
    out = {}
    # 每批最多 60
    for i in range(0, len(codes), 60):
        chunk = codes[i:i + 60]
        secids = ",".join(f"{_em_market_of(c)}.{c}" for c in chunk)
        params = {
            "fltt": "2", "invt": "2", "secids": secids,
            "fields": "f12,f14,f2,f9", "ut": EM_UT, "np": "1",
        }
        ok = False
        for attempt in range(4):
            try:
                r = sess.get("https://push2.eastmoney.com/api/qt/ulist.np/get",
                             params=params, timeout=12)
                r.raise_for_status()
                data = r.json()
                diff = (data.get("data") or {}).get("diff") or []
                for it in diff:
                    code = it.get("f12") or ""
                    if not code:
                        continue
                    pe_raw = it.get("f9")
                    try:
                        pe = float(pe_raw) if pe_raw not in (None, "-", "") else None
                    except (TypeError, ValueError):
                        pe = None
                    out[code] = {
                        "name": str(it.get("f14", "") or "").strip(),
                        "price": it.get("f2"),
                        "pe": pe,
                    }
                ok = True
                break
            except (requests.exceptions.ConnectionError,
                    requests.exceptions.Timeout) as e:
                if attempt == 3:
                    log(f"[w] 东财 ulist 批次失败: {type(e).__name__}")
                else:
                    time.sleep(0.8 * (attempt + 1))
            except Exception as e:
                log(f"[w] 东财 ulist 异常: {type(e).__name__}: {e}")
                ok = True
                break
        time.sleep(0.05)
    return out


def fetch_enough_snaps(codes):
    """隔离一次性子进程拉 PE：腾讯+东财双源，互不拖累主进程。
    主进程在高并发拉 K 线后连接带病(腾讯空响应/东财断连)，但全新 python 子进程干净可用。
    故把 PE 拉取放进一次性子进程(仅 import requests、不 import 本模块)执行。
    返回 {code:{name,price,pe}}，两源结果合并、腾讯优先。"""
    codes = [c for c in codes if c]
    if not codes:
        return {}
    import subprocess
    import sys as _sys
    import json as _json
    # 一次性子进程(不带入主进程连接状态)。实测：判定期刚结束出口对腾讯/东财有瞬时冷却，
    # 需先静默数秒再单次取数(不背靠背轰炸)，安静窗口内一次命中率最高。腾讯优先，缺填东财。
    child = r'''
import requests,json,sys,time
codes=json.loads(sys.argv[1])
time.sleep(6)                       # 静默让瞬时打回冷却消退
UA="Mozilla/5.0"
EM="7eea3edcaed734bea9cbfc24409ed989"
def num(x):
    try: return float(x)
    except: return None
snaps={}
def qt():
    s=requests.Session(); s.headers.update({"User-Agent":UA,"Referer":"https://gu.qq.com/"})
    for i in range(0,len(codes),50):
        syms=",".join(("sh" if c[0]=="6" else "sz")+c for c in codes[i:i+50])
        for a in range(2):
            try:
                r=s.get("https://qt.gtimg.cn/q="+syms+"&_r="+str(int(time.time()*1000)),timeout=12)
                txt=r.content.decode("gbk",errors="ignore")
                if len(txt)<80: raise Exception("short")
                for ln in txt.split(";"):
                    if '="' not in ln: continue
                    body=ln.split('="',1)[1].rstrip('"'); p=body.split("~")
                    if len(p)<40: continue
                    snaps[p[2]]={"name":p[1],"price":num(p[3]),"pe":num(p[39])}
                break
            except Exception:
                if a==1: break
                break
def em(fill):
    if not fill: return
    s=requests.Session(); s.headers.update({"User-Agent":UA,"Referer":"https://quote.eastmoney.com/"})
    for i in range(0,len(fill),55):
        sec=",".join(("1." if c[0] in "695" else "0.")+c for c in fill[i:i+55])
        for a in range(3):
            try:
                r=s.get("https://push2.eastmoney.com/api/qt/ulist.np/get",
                        params={"fltt":"2","secids":sec,"fields":"f12,f14,f2,f9","ut":EM},timeout=12)
                for it in (r.json().get("data") or {}).get("diff") or []:
                    c=it.get("f12") or ""; pr=it.get("f9")
                    snaps.setdefault(c,{"name":str(it.get("f14") or "").strip(),
                                        "price":num(it.get("f2")),
                                        "pe":num(pr) if pr not in (None,"-","") else None})
                break
            except Exception:
                if a==2: break
                time.sleep(1.5)
qt()
em([c for c in codes if c not in snaps])
print(json.dumps(snaps,ensure_ascii=False))
'''
    try:
        r = subprocess.run([_sys.executable, "-c", child, _json.dumps(codes)],
                           capture_output=True, text=True, timeout=150)
        jl = [l for l in r.stdout.splitlines() if l.strip().startswith("{")]
        if r.returncode == 0 and jl:
            got = _json.loads(jl[-1])
            log(f"[i] 隔离子进程取到 PE {len(got)} 只")
            return got
        log(f"[w] 隔离子进程取 PE 失败: {r.stderr[-200:]}")
    except Exception as e:
        log(f"[w] 隔离子进程异常: {type(e).__name__}: {e}")
    return {}


def fetch_qt_snaps_robust(codes):
    """PE快照：先试主进程腾讯(快捷) → 失败立即交给隔离一次性子进程双源拉取。
    避免长主进程内的连接病态/自我冷却，干净子进程几乎必成。"""
    codes = [c for c in codes if c]
    if not codes:
        return {}
    out = fetch_qt_snaps(codes)
    if out:
        return out
    log("[w] 腾讯主进程拉取失败(长进程连接受限)，改隔离一次性子进程双源拉取…")
    return fetch_enough_snaps(codes)


# ---------------------------------------------------------------- 指标计算
def slice_bars(bars, end):
    """截止 end(YYYY-MM-DD) 的 bar 列表"""
    return [b for b in bars if b["day"] <= end]


def ma(closes, n):
    if len(closes) < n:
        return None
    return sum(closes[-n:]) / n


def avg_vol(vols, i, n=5):
    if i - n < 0:
        return None
    return sum(vols[i - n:i]) / n


# ---------------------------------------------------------------- 主池单票判定
def analyze_main_stock(code, bars, end_date, pe_opt, zt_industry):
    """返回 dict 或 None（None=被剔除/不构成候选）"""
    bars = slice_bars(bars, end_date)
    if len(bars) < 130:
        return {"drop": "上市不足/数据不足(<130根)"}
    closes = [b["close"] for b in bars]
    vols = [float(b["volume"]) for b in bars]
    days = [b["day"] for b in bars]

    # ---- ① 涨停基因：近25根K线窗口内找放量非一字涨停 ----
    limit = limit_pct(code)
    zt_min = round(limit * 0.98, 3)
    open_ceiling = limit * 0.7          # 非一字上限(开盘涨幅)
    look = 25
    win_start = max(0, len(bars) - look)
    zt_idx = []
    for i in range(win_start, len(bars)):
        if i == 0:
            continue
        prev_c = closes[i - 1]
        if prev_c <= 0:
            continue
        chg = (closes[i] - prev_c) / prev_c * 100
        if chg < zt_min:
            continue
        o_chg = (bars[i]["open"] - prev_c) / prev_c * 100 if prev_c else 99
        a5 = avg_vol(vols, i, 5)
        if a5 is None or vols[i] < 1.5 * a5:
            continue                      # 未放量
        # 非一字判定：开盘<=0.7*涨停幅度 或 高开但巨量换手(>=3倍，铁证非一字/非T字)
        if o_chg > open_ceiling and vols[i] < 3.0 * a5:
            continue                      # 高开无量 => 一字/T字板，排除
        zt_idx.append(i)
    if not zt_idx:
        return None
    if len(zt_idx) > 3:
        return {"drop": "25日内涨停>3次(过妖)"}

    first_i = zt_idx[0]                  # 首板(基柱)
    if first_i == 0:
        return None
    # 回踩时间窗：涨停距今 <=15 个交易日（手册：15日不启动也走）
    if (len(bars) - 1 - first_i) > 15:
        return {"drop": "涨停>15交易日未启动(超窗)"}
    zb = bars[first_i]
    zb_low = zb["low"]
    zb_open = zb["open"]
    cur = bars[-1]
    cur_close = cur["close"]

    # ---- 破位检查：现价 < 首板最低价 → 形态证伪 ----
    if cur_close < zb_low:
        return {"drop": "破首板低点(形态证伪)"}

    # ---- ② 位置：距250日(可用)最高回撤 + 启动约束 ----
    hi = max(b["high"] for b in bars)
    r_drawdown = (hi - cur_close) / hi if hi else 0
    # 启动低点 = 首板日前60根最低
    base_lo = min(b["low"] for b in bars[max(0, first_i - 60):first_i + 1])
    launch_ok = cur_close <= base_lo * 1.5

    # ---- ③ 回踩：涨停后高点回撤（硬条件 2~18%，最佳2-8%）----
    post_hi = max(b["high"] for b in bars[first_i:])
    dd = (post_hi - cur_close) / post_hi * 100 if post_hi else 0
    if not (2 <= dd <= 18):
        return {"drop": f"非回马枪形态(回撤{dd:.0f}%)"}

    # ---- 回踩缩量（硬条件：回踩段中位量不应大于涨停量1.3倍）----
    after = vols[first_i + 1:] or []
    zt_vol = vols[first_i]
    vol_ratio = 99.0
    if after:
        med_after = sorted(after)[len(after) // 2]
        vol_ratio = med_after / zt_vol if zt_vol else 99.0
    if vol_ratio > 1.3:
        return {"drop": "回踩未缩量(放量回踩)"}

    # ---- 大级别避雷(330日视角) ----
    ma250 = ma(closes, 250)
    ma120 = ma(closes, 120)
    ma60 = ma(closes, 60)
    if len(closes) < 250:
        trend_state = "△"          # 次新无年线，标注不自动剔
    else:
        if cur_close < ma250 and cur_close < ma60:
            return {"drop": "✗大级别空头(年线下+未站60日线)"}
        trend_state = "✓" if cur_close >= ma250 else "△"

    # ---- 三维评分(0-6) ----
    # 位置 0-2
    if r_drawdown >= 0.20:
        p_pos = 2
    elif r_drawdown >= 0.12:
        p_pos = 1
    else:
        p_pos = 0
    if not launch_ok:
        p_pos = max(0, p_pos - 1)
    # 回踩 0-2（2~8%最佳）
    if 2 <= dd <= 8:
        p_retr = 2
    elif 8 < dd <= 18:
        p_retr = 1
    else:
        p_retr = 0
    # 量能 0-2
    if vol_ratio <= 0.7:
        p_vol = 2
    elif vol_ratio <= 1.0:
        p_vol = 1
    else:
        p_vol = 0
    score = p_pos + p_retr + p_vol

    return {
        "code": code,
        "bars": bars,
        "zt_day": days[first_i],
        "zt_idx": first_i,
        "zt_open": zb_open,
        "zt_low": zb_low,
        "zt_high": zb["high"],
        "post_hi": post_hi,
        "close": cur_close,
        "dd": dd,
        "drawdown": r_drawdown * 100,
        "launch_ok": launch_ok,
        "trend_state": trend_state,
        "vol_ratio": vol_ratio,
        "score": score,
        "grade": "A" if score == 6 else "B" if score == 5 else "C" if score == 4 else "D",
    }


# ---------------------------------------------------------------- 长上影变体判定
def analyze_shadow_stock(code, bars, end_date):
    bars = slice_bars(bars, end_date)
    if len(bars) < 40:
        return None
    closes = [b["close"] for b in bars]
    vols = [float(b["volume"]) for b in bars]
    days = [b["day"] for b in bars]
    last = len(bars) - 1
    today = bars[last]

    def is_probe(i):
        """第 i 根是否为 倍量长上影试盘"""
        if i <= 0:
            return False
        a5 = avg_vol(vols, i, 5)
        if a5 is None or vols[i] < 1.5 * a5:
            return False
        o, c, h = bars[i]["open"], bars[i]["close"], bars[i]["high"]
        body_top = max(o, c)
        up_shadow = h - body_top
        if up_shadow < 0.015 * c:          # 上影至少 1.5%
            return False
        body = abs(c - o)
        if up_shadow < 0.5 * max(body, 0.001):
            return False
        # 带攻击性：当日有真实上攻(高点相对昨收)
        if h <= closes[i - 1] * 1.01:
            return False
        return True

    res = {}
    if is_probe(last):
        # strong = 收在日内振幅上半区 且 收阳：攻击后仍守住 = 强试盘
        amp_hi = today["high"] - today["low"]
        strong = (today["close"] >= today["open"]
                  and amp_hi > 0
                  and (today["close"] - today["low"]) >= 0.5 * amp_hi)
        res["today_probe"] = {
            "day": days[last], "high": today["high"],
            "open": today["open"], "close": today["close"],
            "low": today["low"], "strong": strong,
            "vr": vols[last] / avg_vol(vols, last, 5) if avg_vol(vols, last, 5) else 0,
        }
    # 前面<=5日内存在试盘
    probe_before = None
    for j in range(max(0, last - 5), last):
        if is_probe(j):
            probe_before = j
    if probe_before is not None:
        a5 = avg_vol(vols, last, 5)
        vr_today = vols[last] / a5 if a5 else 99
        o, c = today["open"], today["close"]
        stable = (c >= o) or (abs(c - o) / o < 0.012)      # 阳/十字企稳
        if vr_today <= 0.7 and stable and today["low"] > bars[probe_before]["low"] * 0.97:
            res["wash_done"] = {
                "probe_day": days[probe_before],
                "probe_high": bars[probe_before]["high"],
                "probe_low": bars[probe_before]["low"],
                "day": days[last], "close": c, "low": today["low"],
                "vr": vr_today,
            }
    return res or None


# ---------------------------------------------------------------- 主入口
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("date", nargs="?", default=None)
    ap.add_argument("mode", nargs="?", default="main",
                    choices=["main", "longshadow", "fanbao"])
    ap.add_argument("pe", nargs="?", default="tec", choices=["def", "tec"])
    args = ap.parse_args()

    pe_opt = args.pe
    mode = args.mode if args.mode in ("longshadow", "fanbao") else "main"

    # ---- 基准日处理：缺省回退到最近交易日 ----
    if args.date:
        base_d = dt.datetime.strptime(args.date, "%Y%m%d").date()
        date_s = args.date
    else:
        base_d = dt.date.today()
        date_s = base_d.strftime("%Y%m%d")

    # 探测 date 是否为交易日(涨停池有数据)
    probe = fetch_zt_pool(date_s, "zt")
    if not probe:
        log(f"[i] {date_s} 无涨停池数据(非交易日/未开盘)，向前回退最近交易日…")
        d = base_d - dt.timedelta(days=1)
        date_s = None
        while d.weekday() >= 5 or (not (probe := fetch_zt_pool(d.strftime("%Y%m%d"), "zt"))):
            d -= dt.timedelta(days=1)
            if d < base_d - dt.timedelta(days=15):
                log("[x] 15天内找不到交易日，退出")
                sys.exit(1)
        date_s = d.strftime("%Y%m%d")
        log(f"[i] 使用最近交易日 {date_s}")
    base_d = dt.datetime.strptime(date_s, "%Y%m%d").date()
    end_iso = date_s[:4] + "-" + date_s[4:6] + "-" + date_s[6:]

    out_dir = os.path.join(ARCHIVE_ROOT, base_d.strftime("%Y-%m-%d"))
    os.makedirs(out_dir, exist_ok=True)
    log(f"[i] 基准日 {date_s} | 模式 {mode} | PE档 {pe_opt} | 输出目录 {out_dir}")

    if mode == "main":
        run_main(date_s, end_iso, pe_opt, out_dir)
    elif mode == "fanbao":
        run_fanbao(date_s, end_iso, pe_opt, out_dir)
    else:
        run_longshadow(date_s, end_iso, pe_opt, out_dir)


# ---------------------------------------------------------------- 主池流程
def run_main(date_s, end_iso, pe_opt, out_dir):
    # 1) 收集近25个交易日涨停池
    log("[1/5] 拉取近25个交易日涨停池…")
    pools = []                      # list[dict]
    d = dt.datetime.strptime(date_s, "%Y%m%d").date()
    got = 0
    while got < 25:
        if d.weekday() < 5:
            p = fetch_zt_pool(d.strftime("%Y%m%d"), "zt")
            if p:
                pools.extend(p)
                got += 1
        d -= dt.timedelta(days=1)
        if got >= 25 or (dt.datetime.strptime(date_s, "%Y%m%d").date() - d).days > 70:
            break
    cand_map = {}                   # code -> {name, industry}
    for it in pools:
        code = it["c"]
        cand_map.setdefault(code, {
            "name": it.get("n", ""),
            "industry": it.get("hybk", ""),
        })
    log(f"[i] 25日涨停池去重后 {len(cand_map)} 只（含基因候选）")

    # 2) 逐只拉K线判定（并发）
    log("[2/5] 逐只拉日K(新浪)判定五关+评分…")
    from concurrent.futures import ThreadPoolExecutor

    def _work(code):
        bars = fetch_kline(code)
        time.sleep(0.008)
        if not bars:
            return None
        r = analyze_main_stock(code, bars, end_iso, pe_opt, cand_map[code])
        if r is None or "drop" in r:
            return r
        r.update({"name": cand_map[code]["name"],
                  "industry": cand_map[code]["industry"]})
        return r

    hits = []
    drops = {}
    with ThreadPoolExecutor(max_workers=10) as ex:
        for r in ex.map(_work, list(cand_map.keys())):
            if r is None:
                continue
            if "drop" in r:
                drops[r["drop"]] = drops.get(r["drop"], 0) + 1
                continue
            hits.append(r)
    log(f"[i] 形态关通过 {len(hits)} 只；剔除统计: {drops}")

    # 3) PE/ST 快照(腾讯)
    log("[3/5] 拉取 PE/名称 快照(腾讯)…")
    snaps = fetch_qt_snaps_robust([h["code"] for h in hits])
    final = []
    for h in hits:
        sn = snaps.get(h["code"], {})
        name = sn.get("name") or h.get("name", "")
        if is_st(name):
            drops["ST"] = drops.get("ST", 0) + 1
            continue
        pe = sn.get("pe")
        pe_txt = "--"
        if pe is not None and pe > 0:
            pe_txt = f"{pe:.1f}"
            if pe_opt == "tec" and pe > 120:
                drops["PE>120(tec档)"] = drops.get("PE>120(tec档)", 0) + 1
                continue
            if pe_opt == "def" and not (10 <= pe <= 60):
                drops["PE不在10-60(def档)"] = drops.get("PE不在10-60(def档)", 0) + 1
                continue
        elif pe is not None and pe <= 0:
            drops["亏损(PE<=0)"] = drops.get("亏损(PE<=0)", 0) + 1
            continue
        h.update({"name": name, "pe": pe_txt, "price": sn.get("price")})
        final.append(h)

    # 4) 排序分档输出
    order = {"A": 0, "B": 1, "C": 2, "D": 3}
    final.sort(key=lambda x: (order[x["grade"]], -x["score"], x["dd"]))
    log(f"[4/5] 终筛 {len(final)} 只")

    lines = []
    lines.append(f"# 候选池 · {date_s}（回马枪主池）")
    lines.append("")
    lines.append(f"> 基准日：{end_iso}｜PE档：**{pe_opt}**｜机器三维评分(位置/回踩/量能 0-6)")
    lines.append("> 状态：✓年线上｜△分水岭下(抢反弹待遇：仓位减半/只做A/到分水岭先减)")
    lines.append("> ⚠️ 候选池 ≠ 买入池：须等买点信号（缩量企稳/放量收复）；五关④人工终审(澄清/减持/题材第二集)仍须人工过。")
    lines.append("")
    lines.append("## A 级（6分 · 优先做）")
    lines.extend(render_rows([x for x in final if x["grade"] == "A"]))
    lines.append("## B 级（5分 · 可做）")
    lines.extend(render_rows([x for x in final if x["grade"] == "B"]))
    lines.append("## C 级（4分 · 观察）")
    lines.extend(render_rows([x for x in final if x["grade"] == "C"]))
    lines.append("## D 级（<=3分 · 不碰）")
    lines.extend(render_rows([x for x in final if x["grade"] == "D"]))
    lines.append("")
    lines.append("### 机器自动剔除统计")
    for k, v in sorted(drops.items(), key=lambda kv: -kv[1]):
        lines.append(f"- {k}：{v} 只")
    lines.append("")
    lines.append("*数据源：东财涨停池 + 新浪K线 + 腾讯行情。仅供研究参考，不构成投资建议。*")

    fp = os.path.join(out_dir, f"候选池_{date_s}.md")
    with open(fp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    log(f"[5/5] 已写出 {fp}")


def render_rows(items):
    if not items:
        return ["（无）", ""]
    out = [
        "| 代码 | 名称 | 现价 | PE | 涨停日 | 实体底/铁止损 | 涨停后高点 | 高点回撤 | 状态 | 行业 |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    for h in items:
        price = f"{h['price']:.2f}" if h.get("price") else "--"
        out.append(
            f"| {h['code']} | {h['name']} | {price} | {h['pe']} | {h['zt_day']} "
            f"| {h['zt_open']:.2f}/{h['zt_low']:.2f} | {h['post_hi']:.2f} "
            f"| {h['dd']:.1f}% | {h['trend_state']} | {h.get('industry','')} |"
        )
    out.append("")
    return out


# ---------------------------------------------------------------- 变体池流程
def run_longshadow(date_s, end_iso, pe_opt, out_dir):
    log("[1/4] 拉候选池：全市场涨幅榜(>=2%) + 量比榜top300 + 近5日涨停/炸板池…")
    cands = {}

    # A) 涨幅榜分页，直到连续页都 <2%（覆盖全市场攻击股，避免漏盾安类温和放量长上影）
    for page in range(1, 36):
        try:
            data = get_json(SINA_RANK, params={
                "page": page, "num": 100, "sort": "changepercent", "asc": 0,
                "node": "hs_a", "symbol": "", "_s_r_a": "init",
            }, headers=HDR_SINA)
        except Exception:
            data = None
        rows = data or []
        if not rows:
            break
        added = 0
        for it in rows:
            code = it.get("code", "")
            chg = it.get("changepercent")
            try:
                chg = float(chg)
            except (TypeError, ValueError):
                chg = -999
            if chg >= 2.0:
                cands[code] = {"name": it.get("name", "")}
                added += 1
        if added == 0 and len(rows) >= 100:      # 整页都 <2%，停止
            break
        time.sleep(0.12)

    # B) 量比榜 top300（补"放量但涨幅小/收平"的试盘票）
    for page in range(1, 4):
        try:
            data = get_json(SINA_RANK, params={
                "page": page, "num": 100, "sort": "volumeratio", "asc": 0,
                "node": "hs_a", "symbol": "", "_s_r_a": "init",
            }, headers=HDR_SINA)
        except Exception:
            data = None
        for it in (data or []):
            code = it.get("code", "")
            if code:
                cands[code] = {"name": it.get("name", "")}
        time.sleep(0.15)

    # C) 近5交易日 涨停+炸板池
    d = dt.datetime.strptime(date_s, "%Y%m%d").date()
    got = 0
    while got < 5:
        if d.weekday() < 5:
            ds = d.strftime("%Y%m%d")
            for pt in ("zt", "zb"):
                for it in fetch_zt_pool(ds, pt):
                    cands.setdefault(it["c"], {"name": it.get("n", "")})
            got += 1
        d -= dt.timedelta(days=1)
    log(f"[i] 候选去重 {len(cands)} 只")

    log("[2/4] 逐只判 倍量长上影试盘/洗盘完成…")
    from concurrent.futures import ThreadPoolExecutor

    def _work2(item):
        code, meta = item
        bars = fetch_kline(code)
        time.sleep(0.008)
        if not bars:
            return None
        r = analyze_shadow_stock(code, bars, end_iso)
        if not r:
            return None
        return (code, meta["name"], r)

    probes, washes = [], []
    with ThreadPoolExecutor(max_workers=10) as ex:
        for res in ex.map(_work2, list(cands.items())):
            if not res:
                continue
            code, name, r = res
            if "today_probe" in r:
                probes.append({"code": code, "name": name, **r["today_probe"]})
            if "wash_done" in r:
                washes.append({"code": code, "name": name, **r["wash_done"]})

    log(f"[i] 今日新试盘 {len(probes)}｜洗盘完成 {len(washes)}")
    # ---- v3.4.1 补丁：PE/ST 财务过滤（与主池同规格：亏损/缺失/ST剔除，tec≤120 / def 10~60）----
    snaps = fetch_qt_snaps_robust([p["code"] for p in probes + washes])
    drop_reason = {"ST": 0, "亏损(PE<=0)": 0, "PE缺失": 0, "超档(tec>120/def外)": 0}

    def _pe_pass(code, name, pe):
        if is_st(name):
            drop_reason["ST"] += 1
            return False
        if pe is None:
            drop_reason["PE缺失"] += 1
            return False
        if pe <= 0:
            drop_reason["亏损(PE<=0)"] += 1
            return False
        if pe_opt == "tec" and pe > 120:
            drop_reason["超档(tec>120/def外)"] += 1
            return False
        if pe_opt == "def" and not (10 <= pe <= 60):
            drop_reason["超档(tec>120/def外)"] += 1
            return False
        return True

    def _deco(item):
        sn = snaps.get(item["code"], {})
        name = sn.get("name") or ""
        pe = sn.get("pe")
        if name:
            item["name"] = name
        item["pe"] = f"{pe:.1f}" if pe and pe > 0 else "--"
        return _pe_pass(item["code"], name, pe)

    probes = [p for p in probes if _deco(p)]
    washes = [w for w in washes if _deco(w)]
    n_drop = sum(drop_reason.values())
    log(f"[i] v3.4.1 PE/ST 过滤：剔除 {n_drop} 只 {drop_reason}")
    dropped_note = f"> v3.4.1 财务过滤：剔除 {n_drop} 只（{drop_reason}）。" if n_drop else "> v3.4.1 财务过滤：本次无剔除。"

    lines = []
    lines.append(f"# 变体池 · {date_s}（longshadow 长上影洗盘）")
    lines.append("")
    lines.append("> 定义：倍量长上影(量>=前5日均量1.5倍+带攻击) = 试盘；之后缩量(<=0.7)企稳 = 洗盘。")
    lines.append("> 用法：①今日新试盘 = 放进观察，等洗盘完成信号；②洗盘完成 = 可等放量阳线确认再上（买点见手册附录E/F）。")
    lines.append("> ⚠️ 变体池与主池分开管理，**仓位一律减半**。仅供参考，不构成投资建议。")
    lines.append(dropped_note)
    lines.append("")
    # 今日新试盘：滤掉弱信号(量比<1.8)，再分强/普两组
    probes_keep = [p for p in probes if p["vr"] >= 1.8]
    strong = sorted([p for p in probes_keep if p["strong"]], key=lambda x: -x["vr"])
    normal = sorted([p for p in probes_keep if not p["strong"]], key=lambda x: -x["vr"])
    lines.append("## ① 今日新试盘（跟踪 · 量比≥1.8）")
    if len(probes) > len(probes_keep):
        lines.append(f"> 共识别 {len(probes)} 只，其中量比<1.8 的弱信号 {len(probes) - len(probes_keep)} 只已滤除。")
    lines.append("")
    if probes_keep:
        lines.append("### 🔥 强试盘（收在当日上半区 · 攻击后守住，优先观察）")
        lines.append("| 代码 | 名称 | PE | 现价 | 试盘高点 | 关键位(开/收) | 止损(试盘低) | 量比 |")
        lines.append("|---|---|---|---|---|---|---|---|")
        for p in strong:
            lines.append(f"| {p['code']} | {p['name']} | {p['pe']} | {p['close']:.2f} "
                         f"| {p['high']:.2f} | {p['open']:.2f}/{p['close']:.2f} "
                         f"| {p['low']:.2f} | {p['vr']:.1f} |")
        if not strong:
            lines.append("（无）")
        lines.append("")
        lines.append("### 普通试盘（冲高回落，等洗盘后再看）")
        lines.append("| 代码 | 名称 | PE | 现价 | 试盘高点 | 关键位(开/收) | 止损(试盘低) | 量比 |")
        lines.append("|---|---|---|---|---|---|---|---|")
        for p in normal:
            lines.append(f"| {p['code']} | {p['name']} | {p['pe']} | {p['close']:.2f} "
                         f"| {p['high']:.2f} | {p['open']:.2f}/{p['close']:.2f} "
                         f"| {p['low']:.2f} | {p['vr']:.1f} |")
        if not normal:
            lines.append("（无）")
    else:
        lines.append("（今日未发现）")
    lines.append("")
    lines.append("## ② 洗盘完成（等放量确认）")
    if washes:
        lines.append("| 代码 | 名称 | PE | 现价 | 试盘日 | 试盘高点(压力) | 试盘低点(止损) | 今日缩量 |")
        lines.append("|---|---|---|---|---|---|---|---|")
        for p in sorted(washes, key=lambda x: x["vr"]):
            lines.append(f"| {p['code']} | {p['name']} | {p['pe']} | {p['close']:.2f} "
                         f"| {p['probe_day']} | {p['probe_high']:.2f} | {p['probe_low']:.2f} "
                         f"| {p['vr']:.2f} |")
    else:
        lines.append("（今日未发现）")
    lines.append("")
    lines.append("*数据源：新浪全市场榜单 + 东财涨停/炸板池 + 新浪K线。仅供研究参考，不构成投资建议。*")

    fp = os.path.join(out_dir, f"变体池_{date_s}.md")
    with open(fp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    log(f"[4/4] 已写出 {fp}")


# ---------------------------------------------------------------- 反包池流程（v3.5 fanbao）
def run_fanbao(date_s, end_iso, pe_opt, out_dir):
    """反包快洗机器池：涨停倍量阴反包 / 双阴缩量反包 / 炸板反包。
    确认规则：今日放量阳(量比>=1.2)收复事件位；宁缺毋滥。挂附录F卖出。"""
    log("[1/4] 拉取近12个交易日涨停/炸板池…")
    cands = {}
    d = dt.datetime.strptime(date_s, "%Y%m%d").date()
    got = 0
    while got < 12:
        if d.weekday() < 5:
            ds = d.strftime("%Y%m%d")
            for pt in ("zt", "zb"):
                for it in fetch_zt_pool(ds, pt):
                    cands.setdefault(it["c"], {"name": it.get("n", "")})
            got += 1
        d -= dt.timedelta(days=1)
    log(f"[i] 候选去重 {len(cands)} 只")

    log("[2/4] 逐只判 三类反包（今日放量阳收复=确认）…")
    from concurrent.futures import ThreadPoolExecutor

    def _work(item):
        code, meta = item
        bars = fetch_kline(code)
        time.sleep(0.008)
        if not bars:
            return None
        bars = slice_bars(bars, end_iso)
        if len(bars) < 60:
            return None
        closes = [b["close"] for b in bars]
        vols = [float(b["volume"]) for b in bars]
        days = [b["day"] for b in bars]
        n = len(bars)
        last = n - 1
        o, c = bars[last]["open"], bars[last]["close"]
        h, l = bars[last]["high"], bars[last]["low"]
        v = vols[last]
        a5 = avg_vol(vols, last, 5)
        if a5 is None or v < 1.2 * a5:
            return None                    # 确认日必须放量
        vr = v / a5
        if c < o:
            return None                    # 确认日必须收阳
        limit = limit_pct(code)
        zt_min = limit * 0.98
        win_start = max(1, last - 8)

        def is_zt(i):
            if i <= 0 or i >= last:
                return False
            pc = closes[i - 1]
            if pc <= 0:
                return False
            if (closes[i] - pc) / pc * 100 < zt_min:
                return False
            a = avg_vol(vols, i, 5)
            return a is not None and vols[i] >= 1.5 * a

        def is_big_yin(i):
            """倍量阴：收阴、实体>=2%、量>=1.8×前5日均量（巨量分歧）"""
            if i <= 0 or i >= last:
                return False
            if closes[i] >= bars[i]["open"]:
                return False
            body = (bars[i]["open"] - closes[i]) / bars[i]["open"]
            if body < 0.02:
                return False
            a = avg_vol(vols, i, 5)
            return a is not None and vols[i] >= 1.8 * a

        # ---- A 涨停倍量阴反包：涨停→(紧接)倍量阴→今日阳收复阴线开 ----
        for z in range(win_start, last - 1):
            y = z + 1
            if y != z + 1:
                continue
            if not is_zt(z) or not is_big_yin(y):
                continue
            if c <= bars[y]["open"]:
                continue
            strength = "强" if c >= bars[y]["high"] else "标准"
            return ("A_涨停倍量阴反包", meta["name"], {
                "type": "涨停倍量阴反包", "strength": strength,
                "ev_zt": days[z], "ev_bad": days[y],
                "ev_high": bars[y]["high"], "ev_low": bars[y]["low"],
                "recover": bars[y]["open"], "close": c, "vr": vr,
                "note": f"事件 {days[z]}涨停→{days[y]}倍量阴(高点{bars[y]['high']:.2f})，今日{c:.2f}收复阴线开{bars[y]['open']:.2f}"
                + ("【吃事件高·强】" if c >= bars[y]["high"] else "【标准】"),
            })
        # ---- B 双阴缩量反包：涨停→两阴(量递减缩量)→今日放量阳收回 ----
        for z in range(win_start, last - 2):
            y1, y2 = z + 1, z + 2
            if not is_zt(z):
                continue
            if closes[y1] >= bars[y1]["open"] or closes[y2] >= bars[y2]["open"]:
                continue
            if not (vols[y1] <= vols[z] * 0.95 and vols[y2] < vols[y1]):
                continue                    # 两阴相对涨停缩量且递减
            if bars[y2]["low"] < bars[y1]["low"]:
                pass
            if c < bars[y2]["open"]:
                continue
            strength = "强" if c >= bars[y2]["high"] else "标准"
            return ("B_双阴缩量反包", meta["name"], {
                "type": "双阴缩量反包", "strength": strength,
                "ev_zt": days[z], "ev_bad": days[y2],
                "ev_high": bars[y2]["high"], "ev_low": bars[y2]["low"],
                "recover": bars[y2]["open"], "close": c, "vr": vr,
                "note": f"事件 {days[z]}涨停→{days[y1]}/{days[y2]}双阴缩量，今日{c:.2f}放量收复"
                + ("【吃事件高·强】" if c >= bars[y2]["high"] else "【标准】"),
            })
        # ---- C 炸板反包：炸板日(触及涨停未封,长上影)→数日内阳线收复炸板高 ----
        for b in range(win_start, last):
            if last - b > 5:
                continue
            pc = closes[b - 1] if b > 0 else 0
            if pc <= 0:
                continue
            touch = (bars[b]["high"] - pc) / pc * 100 >= limit * 0.75   # 触及近涨停
            if not touch:
                continue
            if bars[b]["close"] >= bars[b]["high"] - 0.001:
                continue                     # 封住/收最高 = 涨停，不是炸板
            up_shadow = (bars[b]["high"] - max(bars[b]["open"], bars[b]["close"])) / bars[b]["high"]
            if up_shadow < 0.015:
                continue                     # 上影不足1.5% 不算炸板
            if c <= bars[b]["high"]:
                continue
            return ("C_炸板反包", meta["name"], {
                "type": "炸板反包", "strength": "强" if c >= bars[b]["high"] * 1.01 else "标准",
                "ev_zt": days[b], "ev_bad": days[b],
                "ev_high": bars[b]["high"], "ev_low": bars[b]["low"],
                "recover": bars[b]["high"], "close": c, "vr": vr,
                "note": f"事件 {days[b]}炸板(冲{pc*(1+limit/200):.2f}回落留上影)，今日{c:.2f}收复炸板高{bars[b]['high']:.2f}",
            })
        return None

    hits = []
    _items = list(cands.items())
    with ThreadPoolExecutor(max_workers=10) as ex:
        for item, res in zip(_items, ex.map(_work, _items)):
            if not res:
                continue
            code, name, info = res
            info.update({"code": info.get("code") or item[0], "name": name})
            hits.append(info)
    log(f"[i] 反包形态命中 {len(hits)} 只（确认日放量阳收复）")
    if hits:
        # （不再落盘 raw json —— 命中信息由下方 md 承接，无下游读取，避免当日夹多余文件）
        log("[i] 命中样本: " + ", ".join(f"{h['code']}{h['name']}({h['type']})" for h in hits[:30]))

    # PE/ST 过滤（同规格；批量拉腾讯快照失败时自动重试）
    log("[3/4] PE/ST 财务过滤…")
    snaps = fetch_qt_snaps_robust([h["code"] for h in hits])
    if not snaps:
        log("[w] 腾讯PE快照拉取失败(3次)，本池按 PE 缺失剔除")
    drop_reason = {"ST": 0, "亏损(PE<=0)": 0, "PE缺失": 0, "超档": 0}
    final = []
    for h in hits:
        sn = snaps.get(h["code"], {})
        name = sn.get("name") or h.get("name", "")
        if name:
            h["name"] = name
        pe = sn.get("pe")
        h["pe"] = f"{pe:.1f}" if pe and pe > 0 else "--"
        if is_st(name):
            drop_reason["ST"] += 1
            continue
        if pe is None:
            drop_reason["PE缺失"] += 1
            continue
        if pe <= 0:
            drop_reason["亏损(PE<=0)"] += 1
            continue
        if pe_opt == "tec" and pe > 120:
            drop_reason["超档"] += 1
            continue
        if pe_opt == "def" and not (10 <= pe <= 60):
            drop_reason["超档"] += 1
            continue
        final.append(h)
    log(f"[i] 过滤后 {len(final)} 只（剔除 {sum(drop_reason.values())} {drop_reason}）")

    # 输出
    order = {"涨停倍量阴反包": 0, "双阴缩量反包": 1, "炸板反包": 2}
    final.sort(key=lambda x: (order.get(x["type"], 9), -x["vr"]))
    lines = []
    lines.append(f"# 反包池 · {date_s}（fanbao 反包快洗）")
    lines.append("")
    lines.append("> 定义：涨停/炸板事件 → 洗盘(倍量阴/双阴缩量) → **今日放量阳收复=反包确认**（宁缺毋滥）。")
    lines.append("> 用法：反包赚次日惯性溢价，**次日统一按附录F卖出手册**（A强拿/B中滞涨减/C弱破位走）；仓位减半。")
    if sum(drop_reason.values()):
        lines.append(f"> v3.4.1 财务过滤：剔除 {sum(drop_reason.values())} 只（{drop_reason}）。")
    lines.append("> ⚠️ 仅供研究参考，不构成投资建议。")
    lines.append("")
    for typ in ("涨停倍量阴反包", "双阴缩量反包", "炸板反包"):
        grp = [h for h in final if h["type"] == typ]
        if not grp:
            continue
        lines.append(f"## {typ.replace('_', '·')}（{len(grp)}只）")
        lines.append("| 代码 | 名称 | PE | 现价 | 事件 | 细节 |")
        lines.append("|---|---|---|---|---|---|")
        for h in grp:
            lines.append(f"| {h['code']} | {h['name']} | {h['pe']} | {h['close']:.2f} "
                         f"| {h['ev_zt']} | {h['note']} |")
        lines.append("")
    if not final:
        lines.append("（今日无符合确认条件的反包票）")
        lines.append("")
    lines.append("*数据源：东财涨停/炸板池 + 新浪K线 + 腾讯行情。仅供研究参考，不构成投资建议。*")

    fp = os.path.join(out_dir, f"反包池_{date_s}.md")
    with open(fp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    log(f"[4/4] 已写出 {fp}")


if __name__ == "__main__":
    main()
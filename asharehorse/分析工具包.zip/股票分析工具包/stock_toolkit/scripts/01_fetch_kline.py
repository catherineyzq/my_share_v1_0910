#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
01_fetch_kline.py —— 抓取 A 股日线数据（东方财富公开接口）

用法:
    python3 01_fetch_kline.py 000997            # 抓新大陆
    python3 01_fetch_kline.py 600845 300         # 抓宝信软件，取 300 根
    python3 01_fetch_kline.py 002487 200 out.csv # 指定输出文件名

说明:
    - 深市代码以 0 开头 -> secid = 0.代码
    - 沪市代码以 6 开头 -> secid = 1.代码
    - 北交所（4/8 开头）需自行确认前缀，本脚本默认按 0 处理
输出:
    <代码>_daily.csv   表头: date,open,close,high,low,vol,amount,amp,pct,chg,turnover
    其中 vol 单位=手, amount 单位=元, pct 单位=%
"""
import sys, os, json, csv, urllib.request

HEADERS = {
    "Referer": "https://quote.eastmoney.com/",
    "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36",
}
FIELDS = "date,open,close,high,low,vol,amount,amp,pct,chg,turnover".split(",")


def guess_secid(code: str) -> str:
    """按首位数字猜市场前缀（沪=1，深=0）"""
    return ("1." if code.startswith("6") else "0.") + code


def fetch(code: str, limit: int = 200, secid: str = None):
    secid = secid or guess_secid(code)
    url = (
        "https://push2his.eastmoney.com/api/qt/stock/kline/get"
        f"?secid={secid}"
        "&fields1=f1,f2,f3,f4,f5,f6"
        "&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61"
        f"&klt=101&fqt=1&end=20500101&lmt={limit}"
    )
    req = urllib.request.Request(url, headers=HEADERS)
    raw = urllib.request.urlopen(req, timeout=25).read().decode("utf-8")
    data = (json.loads(raw).get("data")) or {}
    if not data:
        raise RuntimeError(f"接口返回空数据，请检查代码 {code} / secid {secid}")
    return data.get("name"), data.get("code"), (data.get("klines") or [])


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    code = sys.argv[1].strip()
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 200
    out = sys.argv[3] if len(sys.argv) > 3 else f"{code}_daily.csv"

    name, rcode, klines = fetch(code, limit)
    print(f"名称: {name}  代码: {rcode}  根数: {len(klines)}")

    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(FIELDS)
        for k in klines:
            w.writerow(k.split(","))

    print(f"已保存 -> {os.path.abspath(out)}")
    print("最后 3 根:")
    for k in klines[-3:]:
        print("  ", k)


if __name__ == "__main__":
    main()

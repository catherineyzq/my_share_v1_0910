#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
02_analyze.py —— 日线量价结构分析（均线 / 关键位 / 量能）

用法:
    python3 02_analyze.py 000997_daily.csv
    python3 02_analyze.py 000997_daily.csv --recent 50

输出（纯文本，可直接贴给 AI）:
    - 最新价、涨跌幅、换手
    - MA5/10/20/30/60 及偏离度
    - 区间最高/最低、量能 TOP10
    - 各周期均量对比
    - 最近 N 根 K 线明细
"""
import sys, csv, statistics


def load(path):
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    for r in rows:
        for k in ("open", "close", "high", "low", "vol", "amount", "amp", "pct", "chg", "turnover"):
            try:
                r[k] = float(r[k])
            except (KeyError, ValueError):
                r[k] = 0.0
    return rows


def ma(closes, i, p):
    return None if i + 1 < p else sum(closes[i + 1 - p:i + 1]) / p


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    path = sys.argv[1]
    recent = 50
    if "--recent" in sys.argv:
        recent = int(sys.argv[sys.argv.index("--recent") + 1])

    rows = load(path)
    n = len(rows)
    closes = [r["close"] for r in rows]
    vols = [r["vol"] for r in rows]
    i = n - 1

    print("=" * 62)
    print(f"日线量价结构分析  数据文件: {path}")
    print(f"区间: {rows[0]['date']} ~ {rows[-1]['date']}   共 {n} 根")
    print("=" * 62)

    # 1. 最新状态
    print("\n【1】最新状态")
    print(f"  日期 {rows[i]['date']}  收盘 {closes[i]:.2f}  涨跌 {rows[i]['pct']:+.2f}%  换手 {rows[i]['turnover']:.2f}%")

    # 2. 均线
    print("\n【2】均线（偏离度 = 收盘/均线 - 1）")
    for p in (5, 10, 20, 30, 60):
        m = ma(closes, i, p)
        if m:
            print(f"  MA{p:<3} = {m:8.2f}   偏离 {((closes[i]/m-1)*100):+6.2f}%")
        else:
            print(f"  MA{p:<3} = 数据不足")

    # 3. 区间高低
    hi = max(range(n), key=lambda k: rows[k]["high"])
    lo = min(range(n), key=lambda k: rows[k]["low"])
    print("\n【3】区间高低")
    print(f"  最高 {rows[hi]['high']:.2f}  ({rows[hi]['date']})")
    print(f"  最低 {rows[lo]['low']:.2f}  ({rows[lo]['date']})")
    print(f"  当前距最高 {(closes[i]/rows[hi]['high']-1)*100:+.1f}%   距最低 {(closes[i]/rows[lo]['low']-1)*100:+.1f}%")

    # 4. 量能 TOP10
    print("\n【4】量能 TOP10（天量日）")
    top = sorted(range(n), key=lambda k: -vols[k])[:10]
    for k in sorted(top):
        print(f"  {rows[k]['date']}  量 {int(vols[k]):>9,}  收 {closes[k]:7.2f}  涨跌 {rows[k]['pct']:+6.2f}%  换手 {rows[k]['turnover']:.2f}%")

    # 5. 均量对比
    print("\n【5】各周期均量")
    for seg in (5, 10, 20, 60):
        if n >= seg:
            print(f"  近{seg:>3}日均量 {int(statistics.mean(vols[-seg:])):>9,}")
    print(f"  全  {n:>3}日均量 {int(statistics.mean(vols)):>9,}")

    # 6. 最近 N 根
    print(f"\n【6】最近 {recent} 根 K 线")
    print("  日期        开     收     高     低       量      涨跌%   换手%")
    for k in range(max(0, n - recent), n):
        r = rows[k]
        print(f"  {r['date']}  {r['open']:6.2f} {r['close']:6.2f} {r['high']:6.2f} {r['low']:6.2f} {int(r['vol']):>9,} {r['pct']:+7.2f} {r['turnover']:6.2f}")

    print("\n" + "=" * 62)


if __name__ == "__main__":
    main()

#!/bin/sh
# =========================================================
# 视频工坊 1/2 · V_env_setup.sh
# 幂等搭建本视频产线所需环境（Alpine apk 为主，兼容 Debian/常见发行版）
# 用法：bash V_env_setup.sh
# 说明：成功后再跑 V_pipeline；跨会话共享 rootfs，本框装好后新视频不必重装（除非换机器/被清 ROOTFS）
# =========================================================
echo "== V_env_setup: 探测并补齐 bash / ffmpeg / tesseract(chi_sim) / zip =="

have(){ command -v "$1" >/dev/null 2>&1; }

# --- bash ---
if ! have bash; then echo "[装] bash"; apk add bash >/dev/null 2>&1 || apt-get install -y bash >/dev/null 2>&1 || true; fi
# --- 包管理器探测优先 alpine ---
PKGR="apk add --no-cache"
have apk || PKGR=""
have apt-get && PKGR="apt-get install -y"

# --- ffmpeg ---
if ! have ffmpeg; then echo "[装] ffmpeg"; apk add --no-cache ffmpeg >/dev/null 2>&1 || apt-get install -y ffmpeg >/dev/null 2>&1 || echo " (ffmpeg 安装失败，请手动装)"; fi
# --- tesseract (OCR 简体中文) ---
if ! have tesseract; then echo "[装] tesseract"; apk add --no-cache tesseract-ocr tesseract-ocr-data-chi_sim tesseract-ocr-data-eng >/dev/null 2>&1 || apt-get install -y tesseract-ocr tesseract-ocr-chi-sim >/dev/null 2>&1 || echo " (tesseract 安装失败)"; fi
# --- zip ---
if ! have zip; then echo "[装] zip"; apk add --no-cache zip >/dev/null 2>&1 || apt-get install -y zip >/dev/null 2>&1 || true; fi

echo ""
echo "== 检查结果 =="
for b in bash ffmpeg ffprobe tesseract zip; do
  have "$b" && echo "  ✓ $b: $(command -v $b)" || echo "  ✗ $b 缺失"
done
if have tesseract; then echo "  OCR语言: $(tesseract --list-langs 2>/dev/null | tail -n +2 | tr '\n' ' ')"; fi
echo "== 完成：已具备运行 V_pipeline.sh 的条件 =="
